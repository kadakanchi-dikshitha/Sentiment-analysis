from flask import Flask, render_template, request
import joblib
import os

app = Flask(__name__)

# Load the saved model and vectorizer
model = joblib.load(os.path.join('model', 'sentiment_model.pkl'))
vectorizer = joblib.load(os.path.join('model', 'vectorizer.pkl'))

@app.route('/', methods=['GET', 'POST'])
def index():
    sentiment = None
    if request.method == 'POST':
        text = request.form['text']
        if text.strip():
            text_vector = vectorizer.transform([text])
            prediction = model.predict(text_vector)[0]
            sentiment = "Positive" if prediction == 1 else "Negative"
        else:
            sentiment = "Please enter some text."
    return render_template('index.html', sentiment=sentiment)

if __name__ == '__main__':
    app.run(debug=True)
