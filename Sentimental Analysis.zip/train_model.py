import os
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from datasets import load_dataset

def main():
    print("Downloading IMDb dataset...")
    dataset = load_dataset("imdb")
    
    train_texts = dataset['train']['text']
    train_labels = dataset['train']['label']
    
    print(f"Number of training samples: {len(train_texts)}")
    
    X_train, X_val, y_train, y_val = train_test_split(train_texts, train_labels, test_size=0.2, random_state=42)
    
    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer(max_features=10000, stop_words='english')),
        ('clf', LogisticRegression(max_iter=200))
    ])
    
    print("Training model...")
    pipeline.fit(X_train, y_train)
    
    print("Validating model...")
    preds = pipeline.predict(X_val)
    acc = accuracy_score(y_val, preds)
    print(f"Validation Accuracy: {acc:.4f}")
    
    os.makedirs('model', exist_ok=True)
    joblib.dump(pipeline.named_steps['clf'], 'model/sentiment_model.pkl')
    joblib.dump(pipeline.named_steps['tfidf'], 'model/vectorizer.pkl')
    
    print("Model and vectorizer saved in 'model/' folder.")

if __name__ == "__main__":
    main()
